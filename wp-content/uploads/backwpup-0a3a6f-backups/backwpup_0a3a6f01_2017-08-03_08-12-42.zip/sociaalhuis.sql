-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Gegenereerd op: 27 jul 2017 om 10:00
-- Serverversie: 5.7.14
-- PHP-versie: 7.0.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sociaalhuis`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `BeschikbaarheidSelectAll` ()  BEGIN
	SELECT * FROM sh_beschikbaarheden order by bsbID;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `BestuurderDelete` (IN `pId` INT)  BEGIN
DELETE FROM sh_bestuurders WHERE bestID = pId;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `BestuurderInsert` (OUT `pbestID` INT, IN `pbestVoornaam` VARCHAR(255) CHARACTER SET UTF8, IN `pbestNaam` VARCHAR(255) CHARACTER SET UTF8, IN `pbestInfo` VARCHAR(255) CHARACTER SET UTF8, IN `pbestEmail` VARCHAR(255) CHARACTER SET UTF8, IN `pbestGSM` VARCHAR(255) CHARACTER SET UTF8, IN `pbestTelefoon` VARCHAR(255) CHARACTER SET UTF8, IN `pbestContactpersoon` TINYINT(1), IN `pcvID` INT, IN `pfuncID` INT, IN `pverID` INT)  BEGIN
	INSERT INTO sh_bestuurders
	(
		bestVoornaam,
        bestNaam,
        bestInfo,
        bestEmail,
        bestGSM,
        bestTelefoon,
        bestContactPersoon,
        cvID,
        funcID,
        verID
	)
	VALUES
	(
		pbestVoornaam ,
        pbestNaam ,
	    pbestInfo ,
	    pbestEmail ,
        pbestGSM ,
        pbestTelefoon ,
        pBestContactPersoon ,
        pcvID ,
        pfuncID ,
        pverID  
	);
	SELECT LAST_INSERT_ID() INTO pbestID;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `bestuurderselectAll` ()  BEGIN
	SELECT * FROM sh_bestuurders order by bestNaam;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `BestuurderSelectById` (IN `pbestID` INT)  BEGIN
	SELECT * FROM sh_bestuurders WHERE bestID = pbestID;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `BestuurderUpdate` (IN `pbestID` INT, IN `pbestVoornaam` VARCHAR(255) CHARACTER SET UTF8, IN `pbestNaam` VARCHAR(255) CHARACTER SET UTF8, IN `pbestInfo` VARCHAR(255) CHARACTER SET UTF8, IN `pbestEmail` VARCHAR(255) CHARACTER SET UTF8, IN `pbestGSM` VARCHAR(255) CHARACTER SET UTF8, IN `pbestTelefoon` VARCHAR(255) CHARACTER SET UTF8, IN `pbestContactpersoon` TINYINT(1), IN `pcvID` INT, IN `pfuncID` INT, IN `pverID` INT)  BEGIN
UPDATE sh_bestuurders
SET
	bestVoornaam = pbestVoornaam,
    bestNaam = pbestNaam,
    bestInfo = pbestInfo,
	bestEmail = pbestEmail,
    bestGSM = pbestGSM,
    bestTelefoon = pbestTelefoon,
    bestContactpersoon = pbestContactpersoon,
    cvID = pcvID,
    funcID = pfuncID,
    verID = pverID
WHERE bestId = pbestId;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `ContactVoorkeurSelectAll` ()  BEGIN
	SELECT * FROM sh_contactvoorkeuren order by cvID;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `ContactVoorkeurSelectById` (IN `pId` INT)  BEGIN
	SELECT * FROM sh_contactvoorkeuren WHERE cvID = pId;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `DeelwerkingDelete` (IN `pId` INT)  BEGIN
DELETE FROM sh_deelwerkingen WHERE dwID = pId;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `DeelwerkingInsert` (OUT `pdwID` INT, IN `pdwNaam` VARCHAR(255) CHARACTER SET UTF8, IN `pdwInfo` VARCHAR(255) CHARACTER SET UTF8, IN `pdwActief` TINYINT(1))  BEGIN
	INSERT INTO sh_deelwerkingen
	(
		dwNaam,
		dwInfo,
		dwActief
	)
	VALUES
	(
		pdwNaam,
		pdwInfo,
		pdwActief
	);
	SELECT LAST_INSERT_ID() INTO pdwID;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `DeelwerkingSelectAll` ()  BEGIN
	SELECT * FROM sh_deelwerkingen order by dwNaam;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `DeelwerkingSelectById` (IN `pId` INT)  BEGIN
	SELECT * FROM sh_deelwerkingen
	WHERE dwId = pId;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `DeelwerkingUpdate` (IN `pdwID` INT, IN `pdwNaam` VARCHAR(255) CHARACTER SET UTF8, IN `pdwInfo` VARCHAR(255) CHARACTER SET UTF8, IN `pdwActief` TINYINT(1))  BEGIN
UPDATE sh_deelwerkingen
SET
	dwNaam = pdwNaam,
	dwInfo = pdwInfo,
	dwActief = pdwActief
WHERE dwID = pdwID;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `FotoDelete` (IN `pId` INT)  BEGIN
DELETE FROM sh_fotos WHERE fID = pId;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `FotoInsert` (OUT `pfID` INT, IN `pfNaam` VARCHAR(255) CHARACTER SET UTF8, IN `pvrID` INT, IN `pverID` INT)  BEGIN
	INSERT INTO sh_fotos
	(
		fNaam,
		vrID,
        verID
	)
	VALUES
	(
		pfNaam,
		pvrID,
        pverID
	);
	SELECT LAST_INSERT_ID() INTO pfID;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `FotoSelectById` (IN `pID` INT)  BEGIN
	SELECT * FROM sh_fotos
	WHERE fID = pID;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `FotoSelectByVerenigingId` (IN `pverID` INT)  BEGIN
	SELECT * FROM sh_fotos
	WHERE verID = pverID;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `FotoSelectByVrijwilligerId` (IN `pvrID` INT)  BEGIN
	SELECT * FROM sh_fotos
	WHERE vrID = pvrID;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `FotoUpdate` (IN `pfID` INT, IN `pfNaam` VARCHAR(255) CHARACTER SET UTF8, IN `pvrID` INT, IN `pverID` INT)  BEGIN
UPDATE sh_fotos
SET
	fNaam = pfNaam,
	vrID = pvrID,
    verID = pverID

WHERE fID = pfID;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `FunctieDelete` (IN `pId` INT)  BEGIN
DELETE FROM sh_functies WHERE funcID = pId;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `FunctieInsert` (OUT `pfuncID` INT, IN `pfuncNaam` VARCHAR(255) CHARACTER SET UTF8, IN `pfuncInfo` VARCHAR(255) CHARACTER SET UTF8)  BEGIN
	INSERT INTO sh_functies
	(
		funcNaam,
		funcInfo
	)
	VALUES
	(
		pfuncNaam,
		pfuncInfo
	);
	SELECT LAST_INSERT_ID() INTO pfuncID;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `FunctieSelectAll` ()  BEGIN
	SELECT * FROM sh_functies order by funcNaam;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `FunctieSelectById` (IN `pId` INT)  BEGIN
	SELECT * FROM sh_functies
	WHERE funcID = pId;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `FunctieUpdate` (IN `pfuncID` INT, IN `pfuncNaam` VARCHAR(255) CHARACTER SET UTF8, IN `pfuncInfo` VARCHAR(255) CHARACTER SET UTF8)  BEGIN
UPDATE sh_functies
SET
	funcNaam = pfuncNaam,
	funcInfo = pfuncInfo
WHERE funcID = pfuncID;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `InteresseDelete` (IN `pId` INT)  BEGIN
DELETE FROM sh_interesses WHERE intID = pId;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `InteresseInsert` (OUT `pintID` INT, IN `pintNaam` VARCHAR(255) CHARACTER SET UTF8, IN `pintInfo` VARCHAR(255) CHARACTER SET UTF8, IN `pintActief` TINYINT(1))  BEGIN
	INSERT INTO sh_interesses
	(
		intNaam,
		intInfo,
		intActief
	)
	VALUES
	(
		pintNaam,
		pintInfo,
		pintActief
	);
	SELECT LAST_INSERT_ID() INTO pintID;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `InteresseSelectAll` ()  BEGIN
	SELECT * FROM sh_interesses order by intNaam;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `InteresseSelectById` (IN `pId` INT)  BEGIN
	SELECT * FROM sh_interesses
	WHERE intID = pId;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `InteresseUpdate` (IN `pintID` INT, IN `pintNaam` VARCHAR(255) CHARACTER SET UTF8, IN `pintInfo` VARCHAR(255) CHARACTER SET UTF8, IN `pintActief` TINYINT(1))  BEGIN
UPDATE sh_interesses
SET
	intNaam = pintNaam,
	intInfo = pintInfo,
	intActief = pintActief
WHERE intID = pintID;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `RechtsvormDelete` (IN `pId` INT)  BEGIN
DELETE FROM sh_rechtsvormen WHERE rvID = pId;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `RechtsvormInsert` (OUT `rvID` INT, IN `rvNaam` VARCHAR(255) CHARACTER SET UTF8, IN `rvInfo` VARCHAR(255) CHARACTER SET UTF8)  BEGIN
	INSERT INTO sh_rechtsvormen
	(
		rvNaam,
		rvInfo
	)
	VALUES
	(
		rvNaam,
		rvInfo
	);
	SELECT LAST_INSERT_ID() INTO rvID;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `RechtsvormSelectAll` ()  BEGIN
	SELECT * FROM sh_rechtsvormen order by rvNaam;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `RechtsvormSelectById` (IN `pId` INT)  BEGIN
	SELECT * FROM sh_rechtsvormen
	WHERE rvID = pId;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `RechtsvormUpdate` (IN `prvID` INT, IN `prvNaam` VARCHAR(255) CHARACTER SET UTF8, IN `prvInfo` VARCHAR(255) CHARACTER SET UTF8)  BEGIN
UPDATE sh_rechtsvormen
SET
	rvNaam = prvNaam,
	rvInfo = prvInfo
	
WHERE rvID = prvID;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `SectorDelete` (IN `pId` INT)  BEGIN
DELETE FROM sh_sectoren WHERE secid = pId;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `SectorInsert` (OUT `secid` INT, IN `secnaam` VARCHAR(255) CHARACTER SET UTF8, IN `secinfo` VARCHAR(255) CHARACTER SET UTF8)  BEGIN
	INSERT INTO sh_sectoren
	(
		secnaam,
		secinfo
	)
	VALUES
	(
		secnaam,
		secinfo
	);
	SELECT LAST_INSERT_ID() INTO secid;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `SectorSelectAll` ()  BEGIN
	SELECT * FROM sh_sectoren order by secnaam;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `SectorSelectById` (IN `pId` INT)  BEGIN
	SELECT * FROM sh_sectoren
	WHERE secid = pId;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `SectorUpdate` (IN `psecid` INT, IN `psecnaam` VARCHAR(255) CHARACTER SET UTF8, IN `psecinfo` VARCHAR(255) CHARACTER SET UTF8)  BEGIN
UPDATE sh_sectoren
SET
	secnaam = psecnaam,
	secinfo = psecinfo
	
WHERE secid = psecid;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `SelectBeschikbaarhedenByVrijwilligerId` (IN `pvrId` INT)  BEGIN
SELECT * from sh_vrijwilligerbeschikbaarheden where vrID = pvrId;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `SelectDeelwerkingenByVrijwilligerId` (IN `pvrId` INT)  BEGIN
SELECT * from sh_vrijwilligerdeelwerkingen where vrID = pvrId;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `SelectInteressesByVrijwilligerId` (IN `pvrId` INT)  BEGIN
SELECT * from sh_vrijwilligerinteresses where vrID = pvrId;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `SelectSectorenByVerenigingId` (IN `pverId` INT)  BEGIN
SELECT * from sh_verenigingsectoren where verID = pverId;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `StatusSelectAll` ()  BEGIN
	SELECT * FROM sh_statussen order by sid;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `StatusSelectById` (IN `pId` INT)  BEGIN
	SELECT * FROM sh_statussen WHERE sid = pId;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `VerenigingDelete` (IN `pId` INT)  BEGIN
DELETE FROM sh_verenigingen WHERE verID = pId;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `VerenigingInsert` (OUT `pverID` INT, IN `pverNaam` VARCHAR(255) CHARACTER SET UTF8, IN `pverLocatie` VARCHAR(255) CHARACTER SET UTF8, IN `pverOmschrijving` TEXT(255) CHARACTER SET UTF8, IN `pverWerkingsGebied` VARCHAR(255) CHARACTER SET UTF8, IN `pverWebsite` VARCHAR(255) CHARACTER SET UTF8, IN `pverFacebook` VARCHAR(255) CHARACTER SET UTF8, IN `pverCustomField` VARCHAR(255) CHARACTER SET UTF8, IN `pverActief` TINYINT(1), IN `pverWPUserID` INT, IN `prvID` INT)  BEGIN
	INSERT INTO sh_verenigingen
	(
		verNaam,
        verLocatie,
        verOmschrijving,
        verWerkingsGebied,
        verWebsite,
        verFacebook,
        verCustomField,
        verActief,
        verWPUserID,
        rvID
    )
	VALUES
	(
		pverNaam ,
	    pverLocatie ,
	    pverOmschrijving ,
        pverWerkingsGebied,
        pverWebsite,
        pverFacebook,
        pverCustomField,
        pverActief,
        pverWPUserID,
        prvID
	);
	SELECT LAST_INSERT_ID() INTO pverID;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `VerenigingSectorDelete` (IN `pId` INT)  BEGIN
DELETE FROM `sh_verenigingsectoren`
WHERE versecID = pId;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `VerenigingSectorInsert` (OUT `pversecID` INT, IN `pverID` INT, IN `psecID` INT)  BEGIN
	INSERT INTO sh_verenigingsectoren
	(
		verID,
        secID
	)
	VALUES
	(
		pverID,
        psecID
	);
	SELECT LAST_INSERT_ID() INTO pversecID;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `VerenigingSelectAll` ()  BEGIN
	SELECT * FROM sh_verenigingen order by verNaam;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `VerenigingSelectById` (IN `pverID` INT)  BEGIN
	SELECT * FROM sh_verenigingen WHERE verID = pverID;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `VerenigingSelectByUserId` (IN `pverWPUserID` INT)  BEGIN
	SELECT * FROM sh_verenigingen WHERE pverWPUserID = verWPUserID;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `VerenigingUpdate` (IN `pverID` INT, IN `pverNaam` VARCHAR(255) CHARACTER SET UTF8, IN `pverLocatie` VARCHAR(255) CHARACTER SET UTF8, IN `pverOmschrijving` TEXT(255) CHARACTER SET UTF8, IN `pverWerkingsGebied` VARCHAR(255) CHARACTER SET UTF8, IN `pverWebsite` VARCHAR(255) CHARACTER SET UTF8, IN `pverFacebook` VARCHAR(255) CHARACTER SET UTF8, IN `pverCustomField` VARCHAR(255) CHARACTER SET UTF8, IN `pverActief` TINYINT(1), IN `pverWPUserID` INT, IN `prvID` INT)  BEGIN
UPDATE sh_verenigingen
SET
	verNaam = pverNaam,
	verLocatie = pverLocatie,
    verOmschrijving = pverOmschrijving,
    verWerkingsGebied = pverWerkingsGebied, 
    verWebsite = pverWebsite,
    verFacebook = pverFacebook,
    verCustomField = pverCustomField,
    verActief = pverActief,
    verWPUserID = pverWPUserID,
    rvID = prvID
WHERE verId = pverId;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `VrijwilligerBeschikbaarheidDelete` (IN `pId` INT)  BEGIN
DELETE FROM `sh_vrijwilligerbeschikbaarheden`
WHERE vrbsbID = pId;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `VrijwilligerBeschikbaarheidInsert` (OUT `pvrbsbID` INT, IN `pvrID` INT, IN `pbsbID` INT, IN `pvrbsbInfo` VARCHAR(255) CHARACTER SET UTF8)  BEGIN
	INSERT INTO sh_vrijwilligerbeschikbaarheden
	(
		vrID,
        bsbID,
        vrbsbInfo
	)
	VALUES
	(
		pvrID,
        pbsbID,
        pvrbsbInfo
	);
	SELECT LAST_INSERT_ID() INTO pvrbsbID;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `VrijwilligerDeelwerkingDelete` (IN `pId` INT)  BEGIN
DELETE FROM `sh_vrijwilligerdeelwerkingen`
WHERE vrdwID = pId;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `VrijwilligerDeelwerkingInsert` (OUT `pvrdwID` INT, IN `pvrID` INT, IN `pdwID` INT, IN `pvrdwInfo` VARCHAR(255) CHARACTER SET UTF8)  BEGIN
	INSERT INTO sh_vrijwilligerdeelwerkingen
	(
		vrID,
        dwID,
        vrdwInfo
	)
	VALUES
	(
		pvrID,
        pdwID,
        pvrdwInfo
	);
	SELECT LAST_INSERT_ID() INTO pvrdwID;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `VrijwilligerDelete` (IN `pId` INT)  BEGIN
DELETE FROM sh_vrijwilligers WHERE vrID = pId;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `VrijwilligerInsert` (OUT `pvrID` INT, IN `pvrVoornaam` VARCHAR(255) CHARACTER SET UTF8, IN `pvrNaam` VARCHAR(255) CHARACTER SET UTF8, IN `pvrAdres` VARCHAR(255) CHARACTER SET UTF8, IN `pvrPostCode` VARCHAR(255) CHARACTER SET UTF8, IN `pvrGemeente` VARCHAR(255) CHARACTER SET UTF8, IN `pvrGeboorteDatum` DATE, IN `pvrEmail` VARCHAR(255) CHARACTER SET UTF8, IN `pvrGSM` VARCHAR(255) CHARACTER SET UTF8, IN `pvrTelefoon` VARCHAR(255) CHARACTER SET UTF8, IN `pvrInfo` VARCHAR(255) CHARACTER SET UTF8, IN `pvrComment` VARCHAR(255) CHARACTER SET UTF8, IN `pvrActief` TINYINT(1), IN `psID` INT, IN `pcvID` INT, IN `pvrWPUserID` INT)  BEGIN
	INSERT INTO sh_vrijwilligers
	(
		vrVoornaam,
        vrNaam,
        vrAdres,
        vrPostCode,
        vrGemeente,
        vrGeboorteDatum,
        vrEmail,
        vrGSM,
        vrTelefoon,
        vrInfo,
        vrComment,
        vrActief,
        sID,
        cvID,
        vrWPUserID
	)
	VALUES
	(
		pvrVoornaam ,
        pvrNaam ,
	    pvrAdres ,
	    pvrPostCode ,
        pvrGemeente ,
	    pvrGeboorteDatum ,
        pvrEmail ,
        pvrGSM ,
        pvrTelefoon ,
        pvrInfo ,
        pvrComment ,
        pvrActief ,
        psID ,
        pcvID ,
        pvrWPUserID  
	);
	SELECT LAST_INSERT_ID() INTO pvrID;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `VrijwilligerInteresseDelete` (IN `pId` INT)  BEGIN
DELETE FROM `sh_vrijwilligerinteresses`
WHERE vrintID = pId;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `VrijwilligerInteresseInsert` (OUT `pvrintID` INT, IN `pvrID` INT, IN `pintID` INT, IN `pvrintInfo` VARCHAR(255) CHARACTER SET UTF8)  BEGIN
	INSERT INTO sh_vrijwilligerinteresses
	(
		vrID,
        intID,
        vrintInfo
	)
	VALUES
	(
		pvrID,
        pintID,
        pvrintInfo
	);
	SELECT LAST_INSERT_ID() INTO pvrintID;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `VrijwilligerSelectAll` ()  BEGIN
	SELECT * FROM sh_vrijwilligers order by vrNaam;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `VrijwilligerSelectById` (IN `pvrID` INT)  BEGIN
	SELECT * FROM sh_vrijwilligers WHERE vrID = pvrID;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `VrijwilligerSelectByUserId` (IN `pvrWPUserID` INT)  BEGIN
	SELECT * FROM sh_vrijwilligers WHERE vrWPUserID = pvrWPUserID;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `VrijwilligerSelectByVoornaamNaamGeboorteDatum` (IN `pvrVoornaam` VARCHAR(255) CHARACTER SET UTF8, IN `pvrNaam` VARCHAR(255) CHARACTER SET UTF8, IN `pvrGeboorteDatum` DATE)  BEGIN
	SELECT * FROM sh_vrijwilligers WHERE vrVoornaam = pvrVoornaam AND vrNaam = pvrNaam AND vrGeboortedatum = pvrGeboorteDatum;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `VrijwilligerUpdate` (IN `pvrID` INT, IN `pvrVoornaam` VARCHAR(255) CHARACTER SET UTF8, IN `pvrNaam` VARCHAR(255) CHARACTER SET UTF8, IN `pvrAdres` VARCHAR(255) CHARACTER SET UTF8, IN `pvrPostCode` VARCHAR(255) CHARACTER SET UTF8, IN `pvrGemeente` VARCHAR(255) CHARACTER SET UTF8, IN `pvrGeboorteDatum` DATE, IN `pvrEmail` VARCHAR(255) CHARACTER SET UTF8, IN `pvrGSM` VARCHAR(255) CHARACTER SET UTF8, IN `pvrTelefoon` VARCHAR(255) CHARACTER SET UTF8, IN `pvrInfo` VARCHAR(255) CHARACTER SET UTF8, IN `pvrComment` VARCHAR(255) CHARACTER SET UTF8, IN `pvrActief` TINYINT(1), IN `psID` INT, IN `pcvID` INT, IN `pvrWPUserID` INT)  BEGIN
UPDATE sh_vrijwilligers
SET
	vrVoornaam = pvrVoornaam,
    vrNaam = pvrNaam,
	vrAdres = pvrAdres,
    vrPostCode = pvrPostCode,
    vrGemeente = pvrGemeente, 
    vrGeboorteDatum = pvrGeboorteDatum,
	vrEmail = pvrEmail,
    vrGSM = pvrGSM,
    vrTelefoon = pvrTelefoon,
    vrInfo = pvrInfo,
    vrComment = pvrComment,
    vrActief = pvrActief,
    sID = psID,
    cvID = pcvID,
    vrWPUserID = pvrWPUserID
WHERE vrId = pvrId;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `sh_beschikbaarheden`
--

CREATE TABLE `sh_beschikbaarheden` (
  `bsbID` int(11) NOT NULL,
  `bsbNaam` varchar(255) CHARACTER SET utf8 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Gegevens worden geëxporteerd voor tabel `sh_beschikbaarheden`
--

INSERT INTO `sh_beschikbaarheden` (`bsbID`, `bsbNaam`) VALUES
(1, 'Maandag Voormiddag'),
(2, 'Maandag Namiddag'),
(3, 'Maandag Avond'),
(4, 'Dinsdag Voormiddag'),
(5, 'Dinsdag Namiddag'),
(6, 'Dinsdag Avond'),
(7, 'Woensdag Voormiddag'),
(8, 'Woensdag Namiddag'),
(9, 'Woensdag Avond'),
(10, 'Donderdag Voormiddag'),
(11, 'Donderdag Namiddag'),
(12, 'Donderdag Avond'),
(13, 'Vrijdag Voormiddag'),
(14, 'Vrijdag Namiddag'),
(15, 'Vrijdag Avond'),
(16, 'Zaterdag Voormiddag'),
(17, 'Zaterdag Namiddag'),
(18, 'Zaterdag Avond'),
(19, 'Zondag Voormiddag'),
(20, 'Zondag Namiddag'),
(21, 'Zondag Avond');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `sh_contactvoorkeuren`
--

CREATE TABLE `sh_contactvoorkeuren` (
  `cvID` int(11) NOT NULL,
  `cvVoorkeur` varchar(255) CHARACTER SET utf8 DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Gegevens worden geëxporteerd voor tabel `sh_contactvoorkeuren`
--

INSERT INTO `sh_contactvoorkeuren` (`cvID`, `cvVoorkeur`) VALUES
(1, 'E-mail'),
(2, 'GSM'),
(3, 'Telefoon');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `sh_deelwerkingen`
--

CREATE TABLE `sh_deelwerkingen` (
  `dwID` int(11) NOT NULL,
  `dwNaam` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `dwInfo` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `dwActief` tinyint(1) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Gegevens worden geëxporteerd voor tabel `sh_deelwerkingen`
--

INSERT INTO `sh_deelwerkingen` (`dwID`, `dwNaam`, `dwInfo`, `dwActief`) VALUES
(1, 'Boodschappendienst', 'DC \'t Vijverhof', 1),
(2, 'Dorpresto Saar', 'Sociaal Huis', 1),
(3, 'Huiswerkbegeleiding', 'Sociaal Huis', 1),
(4, 'Huyse Kenhoft', 'Dagverzorgingscentrum', 0),
(5, 'DC \'t Vijverhof', 'Algemeen', 1),
(6, 'Tinah', 'Sociaal Huis', 0),
(8, 'Minder Mobielen Centrale', 'DC \'t Vijverhof', 1),
(9, 'Luna di Tanneke', 'project van sociaal huis', 0),
(10, 'Kamers met uitzicht', 'sociaal huis', 1);

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `sh_fotos`
--

CREATE TABLE `sh_fotos` (
  `fID` int(11) NOT NULL,
  `fNaam` varchar(255) CHARACTER SET utf8 NOT NULL,
  `vrID` int(11) DEFAULT NULL,
  `verID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Gegevens worden geëxporteerd voor tabel `sh_fotos`
--

INSERT INTO `sh_fotos` (`fID`, `fNaam`, `vrID`, `verID`) VALUES
(1, 'Piet.jpg', 3, NULL),
(2, 'Hans.gif', 4, NULL),
(4, 'Mivalti.jpg', NULL, 3);

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `sh_functies`
--

CREATE TABLE `sh_functies` (
  `funcID` int(11) NOT NULL,
  `funcNaam` varchar(255) CHARACTER SET utf8 NOT NULL,
  `funcInfo` varchar(255) CHARACTER SET utf8 DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Gegevens worden geëxporteerd voor tabel `sh_functies`
--

INSERT INTO `sh_functies` (`funcID`, `funcNaam`, `funcInfo`) VALUES
(1, 'Penningmeester', 'vzw'),
(2, 'Secretaris', 'vzw'),
(3, 'Secretaris-Penningmeester', NULL),
(4, 'Voorzitter', 'vzw'),
(5, 'Directeur', 'Stichting');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `sh_interesses`
--

CREATE TABLE `sh_interesses` (
  `intID` int(11) NOT NULL,
  `intNaam` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `intInfo` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `intActief` tinyint(1) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Gegevens worden geëxporteerd voor tabel `sh_interesses`
--

INSERT INTO `sh_interesses` (`intID`, `intNaam`, `intInfo`, `intActief`) VALUES
(1, 'Administratie', NULL, 1),
(2, 'Animatie', 'bvb in rusthuis', 1),
(3, 'Bar', NULL, 1),
(4, 'Boeken voorlezen', NULL, 1),
(5, 'Boodschappen doen', NULL, 1),
(6, 'Buddy werking', '', 1),
(7, 'Coaching', NULL, 1),
(8, 'Communicatie', 'Gesproken en geschreven', 1),
(10, 'Dieren', 'wandelen met honden', 1);

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `sh_sectoren`
--

CREATE TABLE `sh_sectoren` (
  `secID` int(11) NOT NULL,
  `secNaam` varchar(255) CHARACTER SET utf8 NOT NULL,
  `secInfo` varchar(255) CHARACTER SET utf8 DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Gegevens worden geëxporteerd voor tabel `sh_sectoren`
--

INSERT INTO `sh_sectoren` (`secID`, `secNaam`, `secInfo`) VALUES
(1, 'Cultuur', NULL),
(2, 'Jeugd', NULL),
(3, 'Sport', NULL),
(4, 'Senioren', NULL),
(5, 'Welzijn', NULL),
(6, 'Andere', NULL);

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `sh_statussen`
--

CREATE TABLE `sh_statussen` (
  `sID` int(11) NOT NULL,
  `sNaam` varchar(255) CHARACTER SET utf8 DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Gegevens worden geëxporteerd voor tabel `sh_statussen`
--

INSERT INTO `sh_statussen` (`sID`, `sNaam`) VALUES
(1, 'Goedgekeurd'),
(2, 'Afgekeurd');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `sh_verenigingsectoren`
--

CREATE TABLE `sh_verenigingsectoren` (
  `versecID` int(11) NOT NULL,
  `verID` int(11) NOT NULL,
  `secID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Gegevens worden geëxporteerd voor tabel `sh_verenigingsectoren`
--

INSERT INTO `sh_verenigingsectoren` (`versecID`, `verID`, `secID`) VALUES
(1, 1, 2),
(2, 3, 4),
(16, 38, 6),
(17, 38, 1),
(21, 19, 1),
(23, 41, 1);

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `sh_vrijwilligerbeschikbaarheden`
--

CREATE TABLE `sh_vrijwilligerbeschikbaarheden` (
  `vrbsbID` int(11) NOT NULL,
  `bsbID` int(11) NOT NULL,
  `vrID` int(11) NOT NULL,
  `vrbsbInfo` varchar(255) CHARACTER SET utf8 DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Gegevens worden geëxporteerd voor tabel `sh_vrijwilligerbeschikbaarheden`
--

INSERT INTO `sh_vrijwilligerbeschikbaarheden` (`vrbsbID`, `bsbID`, `vrID`, `vrbsbInfo`) VALUES
(1, 1, 1, NULL),
(2, 2, 1, 'slechts 2 uren');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `sh_vrijwilligerdeelwerkingen`
--

CREATE TABLE `sh_vrijwilligerdeelwerkingen` (
  `vrdwID` int(11) NOT NULL,
  `dwID` int(11) NOT NULL,
  `vrID` int(11) NOT NULL,
  `vrdwInfo` varchar(255) CHARACTER SET utf8 DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Gegevens worden geëxporteerd voor tabel `sh_vrijwilligerdeelwerkingen`
--

INSERT INTO `sh_vrijwilligerdeelwerkingen` (`vrdwID`, `dwID`, `vrID`, `vrdwInfo`) VALUES
(1, 1, 1, NULL),
(2, 2, 1, 'af en toe');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `sh_vrijwilligerinteresses`
--

CREATE TABLE `sh_vrijwilligerinteresses` (
  `vrintID` int(11) NOT NULL,
  `intID` int(11) NOT NULL,
  `vrID` int(11) NOT NULL,
  `vrintInfo` varchar(255) CHARACTER SET utf8 DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Gegevens worden geëxporteerd voor tabel `sh_vrijwilligerinteresses`
--

INSERT INTO `sh_vrijwilligerinteresses` (`vrintID`, `intID`, `vrID`, `vrintInfo`) VALUES
(1, 1, 1, NULL),
(3, 2, 1, 'slechts 2 uren');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `sh_vrijwilligers`
--

CREATE TABLE `sh_vrijwilligers` (
  `vrID` int(11) NOT NULL,
  `vrVoornaam` varchar(255) DEFAULT NULL,
  `vrNaam` varchar(255) DEFAULT NULL,
  `vrAdres` varchar(255) CHARACTER SET utf8 NOT NULL,
  `vrPostCode` varchar(255) CHARACTER SET utf8 NOT NULL,
  `vrGemeente` varchar(255) CHARACTER SET utf8 NOT NULL,
  `vrGeboorteDatum` date NOT NULL,
  `vrTelefoon` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `vrGSM` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `vrEmail` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `vrInfo` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `vrComment` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `vrActief` tinyint(1) DEFAULT '0',
  `sID` int(11) DEFAULT NULL,
  `cvID` int(11) DEFAULT NULL,
  `vrWPUserID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Gegevens worden geëxporteerd voor tabel `sh_vrijwilligers`
--

INSERT INTO `sh_vrijwilligers` (`vrID`, `vrVoornaam`, `vrNaam`, `vrAdres`, `vrPostCode`, `vrGemeente`, `vrGeboorteDatum`, `vrTelefoon`, `vrGSM`, `vrEmail`, `vrInfo`, `vrComment`, `vrActief`, `sID`, `cvID`, `vrWPUserID`) VALUES
(1, 'Janssens', 'Jan', 'Deken Darraslaan 12', '8700', 'Tielt', '1980-02-05', '051/401223', NULL, 'jan.janssens@yahoo.com', NULL, NULL, 1, NULL, 1, 1),
(3, 'Hans', 'Hanssens', 'Markt 2', '8700', 'Tielt', '1970-10-15', NULL, '0479/584123', 'hhh@skynet.be', 'blabla', NULL, 1, NULL, 1, 3),
(4, 'Jan', 'Janssens', 'Vredestraat 5', '8700', 'Tielt', '1950-10-14', '051/401447', '0477/123456', 'josj@skynet.be', 'Geen info', 'Lui', 1, 1, 2, 2),
(6, 'Hans', 'Hanssens', 'Markt 2', '8700', 'Tielt', '1970-10-15', NULL, '0479/584123', 'hhh@skynet.be', 'blabla', NULL, 1, NULL, 1, 4),
(7, 'Mie', 'Mietens', 'Markt 5', '8700', 'Tielt', '1950-10-14', NULL, NULL, 'mie.mietens@skynet.be', 'Geen info', NULL, 1, NULL, 1, 9),
(8, 'Bert', 'bertens', 'Berestraat 6', '8700', 'aarsele', '1940-02-01', '', '0499562314', '', '', NULL, 1, NULL, 2, 8),
(23, 'Tania', 'Tanens', 'Ter beke 8', '8600', 'kortrijk', '2016-03-08', '', '0477/562312', '', '', NULL, 0, NULL, 2, 12),
(25, 'Jos', 'Jolens', 'Vredestraat 5', '8700', 'Tielt', '1950-10-14', '051/401447', '0477/123456', 'josj@skynet.be', 'Geen info', 'Lui', 1, 1, 2, 5);

--
-- Indexen voor geëxporteerde tabellen
--

--
-- Indexen voor tabel `sh_beschikbaarheden`
--
ALTER TABLE `sh_beschikbaarheden`
  ADD PRIMARY KEY (`bsbID`);

--
-- Indexen voor tabel `sh_contactvoorkeuren`
--
ALTER TABLE `sh_contactvoorkeuren`
  ADD PRIMARY KEY (`cvID`);

--
-- Indexen voor tabel `sh_deelwerkingen`
--
ALTER TABLE `sh_deelwerkingen`
  ADD PRIMARY KEY (`dwID`);

--
-- Indexen voor tabel `sh_fotos`
--
ALTER TABLE `sh_fotos`
  ADD PRIMARY KEY (`fID`),
  ADD KEY `fkc_fotos_vrijwilligers` (`vrID`),
  ADD KEY `fkc_fotos_verenigingen` (`verID`);

--
-- Indexen voor tabel `sh_functies`
--
ALTER TABLE `sh_functies`
  ADD PRIMARY KEY (`funcID`);

--
-- Indexen voor tabel `sh_interesses`
--
ALTER TABLE `sh_interesses`
  ADD PRIMARY KEY (`intID`);

--
-- Indexen voor tabel `sh_sectoren`
--
ALTER TABLE `sh_sectoren`
  ADD PRIMARY KEY (`secID`);

--
-- Indexen voor tabel `sh_statussen`
--
ALTER TABLE `sh_statussen`
  ADD PRIMARY KEY (`sID`);

--
-- Indexen voor tabel `sh_verenigingsectoren`
--
ALTER TABLE `sh_verenigingsectoren`
  ADD PRIMARY KEY (`versecID`),
  ADD KEY `fkc_verenigingsectoren_verenigingen` (`verID`),
  ADD KEY `fkc_verenigingsectoren_sectoren` (`secID`);

--
-- Indexen voor tabel `sh_vrijwilligerbeschikbaarheden`
--
ALTER TABLE `sh_vrijwilligerbeschikbaarheden`
  ADD PRIMARY KEY (`vrbsbID`),
  ADD KEY `fkc_vrijwilligerbeschikbaarheden_vrijwilligers` (`vrID`),
  ADD KEY `fkc_vrijwilligerbeschikbaarheden_beschikbaarheden` (`bsbID`);

--
-- Indexen voor tabel `sh_vrijwilligerdeelwerkingen`
--
ALTER TABLE `sh_vrijwilligerdeelwerkingen`
  ADD PRIMARY KEY (`vrdwID`),
  ADD KEY `fkc_vrijwilligerdeelwerkingen_vrijwilligers` (`vrID`),
  ADD KEY `fkc_vrijwilligerdeelwerkingen_deelwerkingen` (`dwID`);

--
-- Indexen voor tabel `sh_vrijwilligerinteresses`
--
ALTER TABLE `sh_vrijwilligerinteresses`
  ADD PRIMARY KEY (`vrintID`),
  ADD KEY `fkc_vrijwilligerinteresses_vrijwilligers` (`vrID`),
  ADD KEY `fkc_vrijwilligerinteresses_interesses` (`intID`);

--
-- Indexen voor tabel `sh_vrijwilligers`
--
ALTER TABLE `sh_vrijwilligers`
  ADD PRIMARY KEY (`vrID`),
  ADD UNIQUE KEY `uc_vrWPUserID` (`vrWPUserID`),
  ADD KEY `fkc_vrijwilligers_contactvoorkeuren` (`cvID`),
  ADD KEY `fkc_vrijwilligers_statussen` (`sID`);

--
-- AUTO_INCREMENT voor geëxporteerde tabellen
--

--
-- AUTO_INCREMENT voor een tabel `sh_beschikbaarheden`
--
ALTER TABLE `sh_beschikbaarheden`
  MODIFY `bsbID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;
--
-- AUTO_INCREMENT voor een tabel `sh_contactvoorkeuren`
--
ALTER TABLE `sh_contactvoorkeuren`
  MODIFY `cvID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT voor een tabel `sh_deelwerkingen`
--
ALTER TABLE `sh_deelwerkingen`
  MODIFY `dwID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT voor een tabel `sh_fotos`
--
ALTER TABLE `sh_fotos`
  MODIFY `fID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT voor een tabel `sh_functies`
--
ALTER TABLE `sh_functies`
  MODIFY `funcID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT voor een tabel `sh_interesses`
--
ALTER TABLE `sh_interesses`
  MODIFY `intID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT voor een tabel `sh_sectoren`
--
ALTER TABLE `sh_sectoren`
  MODIFY `secID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT voor een tabel `sh_statussen`
--
ALTER TABLE `sh_statussen`
  MODIFY `sID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT voor een tabel `sh_verenigingsectoren`
--
ALTER TABLE `sh_verenigingsectoren`
  MODIFY `versecID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;
--
-- AUTO_INCREMENT voor een tabel `sh_vrijwilligerbeschikbaarheden`
--
ALTER TABLE `sh_vrijwilligerbeschikbaarheden`
  MODIFY `vrbsbID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT voor een tabel `sh_vrijwilligerdeelwerkingen`
--
ALTER TABLE `sh_vrijwilligerdeelwerkingen`
  MODIFY `vrdwID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT voor een tabel `sh_vrijwilligerinteresses`
--
ALTER TABLE `sh_vrijwilligerinteresses`
  MODIFY `vrintID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT voor een tabel `sh_vrijwilligers`
--
ALTER TABLE `sh_vrijwilligers`
  MODIFY `vrID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;
--
-- Beperkingen voor geëxporteerde tabellen
--

--
-- Beperkingen voor tabel `sh_fotos`
--
ALTER TABLE `sh_fotos`
  ADD CONSTRAINT `fkc_fotos_vrijwilligers` FOREIGN KEY (`vrID`) REFERENCES `sh_vrijwilligers` (`vrID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Beperkingen voor tabel `sh_verenigingsectoren`
--
ALTER TABLE `sh_verenigingsectoren`
  ADD CONSTRAINT `fkc_verenigingsectoren_sectoren` FOREIGN KEY (`secID`) REFERENCES `sh_sectoren` (`secID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Beperkingen voor tabel `sh_vrijwilligerbeschikbaarheden`
--
ALTER TABLE `sh_vrijwilligerbeschikbaarheden`
  ADD CONSTRAINT `fkc_vrijwilligerbeschikbaarheden_beschikbaarheden` FOREIGN KEY (`bsbID`) REFERENCES `sh_beschikbaarheden` (`bsbID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fkc_vrijwilligerbeschikbaarheden_vrijwilligers` FOREIGN KEY (`vrID`) REFERENCES `sh_vrijwilligers` (`vrID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Beperkingen voor tabel `sh_vrijwilligerdeelwerkingen`
--
ALTER TABLE `sh_vrijwilligerdeelwerkingen`
  ADD CONSTRAINT `fkc_vrijwilligerdeelwerkingen_deelwerkingen` FOREIGN KEY (`dwID`) REFERENCES `sh_deelwerkingen` (`dwID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fkc_vrijwilligerdeelwerkingen_vrijwilligers` FOREIGN KEY (`vrID`) REFERENCES `sh_vrijwilligers` (`vrID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Beperkingen voor tabel `sh_vrijwilligerinteresses`
--
ALTER TABLE `sh_vrijwilligerinteresses`
  ADD CONSTRAINT `fkc_vrijwilligerinteresses_interesses` FOREIGN KEY (`intID`) REFERENCES `sh_interesses` (`intID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fkc_vrijwilligerinteresses_vrijwilligers` FOREIGN KEY (`vrID`) REFERENCES `sh_vrijwilligers` (`vrID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Beperkingen voor tabel `sh_vrijwilligers`
--
ALTER TABLE `sh_vrijwilligers`
  ADD CONSTRAINT `fkc_vrijwilligers_contactvoorkeuren` FOREIGN KEY (`cvID`) REFERENCES `sh_contactvoorkeuren` (`cvID`) ON UPDATE CASCADE,
  ADD CONSTRAINT `fkc_vrijwilligers_statussen` FOREIGN KEY (`sID`) REFERENCES `sh_statussen` (`sID`) ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
